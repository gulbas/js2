"use strict";

class Cart {
    constructor(div) {
        this.countGoods = 0;
        this.amount = 0;
        this.div = document.getElementById(div);
        this.cartItems = [];
    }

    addGoodInCart(button) {
        button.addEventListener('click', () => {
            this.countGoods++;
            this.refresh();
            console.log(this.parentElement.getAttribute('data-id'));
        });
    }

    render() {
        const divCart = this.div,
            title = document.createElement('h1'),
            amount = document.createElement('p'),
            countGoods = document.createElement('p');

        title.innerText = 'Корзина';
        amount.innerHTML = `Общаяя стоимость: ${this.amount}</p>`;
        countGoods.innerHTML = `Всего товаров: ${this.countGoods}`;

        divCart.appendChild(title);
        divCart.appendChild(countGoods);
        divCart.appendChild(amount);
    }

    refresh() {
        this.div.innerHTML = '';
        this.render();
    }

    foreach() {
        // goodsArray.forEach(function (item, i, arr) {
        //     console.log( i + ": " + item + " (массив:" + arr + ")" );
        // });
        goodsArray.findIndex(val => val.id === id)
    }
}