import './style.sass';

import './authorization';

import GoodsList from './GoodList';

const goodsList = new GoodsList();

